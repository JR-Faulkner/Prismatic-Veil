[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s

[Defaults]
command.time = 15
command.buffer.time = 1

[Command]
name = "Momentum Fist"
command = ~D,DF,F,x
time = 15

[Command]
name = "Blitz Rush"
command = ~D,DF,F,y
time = 15

[Command]
name = "prototype punch"
command = x
time = 1

[Statedef -1]

[State -1, Momentum Fist]
type = ChangeState
value = 1000
triggerall = command = "Momentum Fist"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Blitz Rush]
type = ChangeState
value = 1070
triggerall = command = "Blitz Rush"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Prototype Punch]
type = ChangeState
value = 200
triggerall = command = "prototype punch"
triggerall = statetype != A
trigger1 = ctrl
