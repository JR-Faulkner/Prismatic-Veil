[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s

[Defaults]
command.time = 15
command.buffer.time = 1

[Command]
name = "Momentum Fist"
command = ~D,DF,F,x
time = 15

[Command]
name = "Blitz Rush"
command = ~D,DF,F,y
time = 15

[Command]
name = "prototype punch"
command = x
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "probe_x"
command = x
time = 1

[Command]
name = "probe_y"
command = y
time = 1

[Command]
name = "probe_z"
command = z
time = 1

[Command]
name = "probe_a"
command = a
time = 1

[Command]
name = "probe_b"
command = b
time = 1

[Command]
name = "probe_c"
command = c
time = 1

[Statedef -1]

; v0.3B INPUT GATE
[State -1, Probe X]
type = ChangeState
value = 200
triggerall = command = "probe_x"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Probe Y]
type = ChangeState
value = 1000
triggerall = command = "probe_y"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Probe Z]
type = ChangeState
value = 1070
triggerall = command = "probe_z"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Probe A]
type = ChangeState
value = 200
triggerall = command = "probe_a"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Probe B]
type = ChangeState
value = 1000
triggerall = command = "probe_b"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Probe C]
type = ChangeState
value = 1070
triggerall = command = "probe_c"
triggerall = statetype != A
trigger1 = ctrl


[State -1, Momentum Fist]
type = ChangeState
value = 1000
triggerall = command = "Momentum Fist"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Blitz Rush]
type = ChangeState
value = 1070
triggerall = command = "Blitz Rush"
triggerall = statetype != A
trigger1 = ctrl

[State -1, Prototype Punch]
type = ChangeState
value = 200
triggerall = command = "prototype punch"
triggerall = statetype != A
trigger1 = ctrl
