# PriZim Ingest Pack v0.1

This pack contains the four locked production-authority sequence sheets needed
for Auryi and Kineza active-turn presentation.

## Contents
- authority_originals/: untouched user-supplied source images
- production_masters/: cleanup-only transparent PNG derivatives
- manifest.json: machine-readable authority, sequence, grid, and repo destination data
- SHA256SUMS.txt: integrity hashes

## Production rules
- Do not regenerate or reinterpret these assets.
- The source image is visual/choreography authority.
- Production cleanup may remove transport matte, divider artifacts, frame labels,
  and may apply PriZim registration/timing corrections.
- Runtime slices are 3x2 sheets, six frames, 512x512 each.

## Expected repo destinations
- assets/sequences/production/auryi_auorb_entrance_master_a.png
- assets/sequences/production/auryi_attack_master_a.png
- assets/sequences/production/kineza_gauntlet_ignition_master_a.png
- assets/sequences/production/kineza_attack_master_a.png

After ingestion, run the four PriZim checks listed in manifest.json.
